using System;
using System.Collections;
using System.Text;

namespace GLScript
{
    class GLScript
    {
        static void Main(string[] args)
        {

			test1();
			System.Console.WriteLine("Appuyez sur une touche");
            System.Console.ReadKey();
        }
		static void test1()
		{
			string myBuff = "";
			GLDebug.Debug myDebug;


			System.IO.StreamReader tr = new System.IO.StreamReader("test.gls");
			while (true)
			{
				if (tr.EndOfStream)
					break;
				myBuff += tr.ReadLine() + "\n";
			}
			tr.Close();

			myDebug = new GLDebug.Debug("./logs");
			myDebug.AddDebugOutput("err", "err.log");
			myDebug.AddDebugOutput("mss", "mss.log");
			GLApp myApp = new GLApp(myDebug, "Test Application");
			myApp.registerFunction("maFonction", myBuff, "$arg1,$arg2", "none", 1, "",null,null);
			myApp.registerFunction("maFonction2", "writeLine( \"coucou\");\nreturn(\"Voil� un test: \" . $a . \" --- Glob Var: \" . $toto[1]);\nwriteLine( \"caca\");", "$a,$b,$c", "none", 1, "", null, null);
			myApp.registerFunction("GetCurrentPlayerVar", "", "$a ", "none", 1, "", null, null);
			myApp.registerFunction("GetLapperVar", "", "$a ", "none", 1, "", null, null);
			myApp.registerFunction("LangEngine", "", "$a ", "none", 1, "", null, null);
			myApp.registerFunction("PrivMsg", "", "$a,$a,$a,$a,$a", "none", 1, "", null, null);

			ArrayList argVals = new ArrayList();
			argVals.Add("10");
			argVals.Add("Argument2");
			try
			{
				myApp.executeFunction("maFonction", (string[])argVals.ToArray(typeof(string)));
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error in LFSLapper. Look at " + myDebug.getFileName("err"));
				myDebug.printDateOnEachLine = false;
				myDebug.WriteSeparator("err");
				myDebug.WriteLineDate("err");
				myDebug.WriteLine("err", "The following error occurred in " + ex.Source);
				myDebug.WriteLine("err", ex.Message);   // Print the error message.
				myDebug.WriteLine("err", ex.StackTrace); //String that contains the stack trace for this exception.
				myDebug.WriteLine("err", ex.TargetSite.ToString()); //String that contains the stack trace for this exception.
				myDebug.WriteLine("err", "");
				myDebug.WriteSeparator("err");
				myDebug.printDateOnEachLine = true;
				System.Threading.Thread.Sleep(15000);

			}
		}

        static void myFunctions(unionVal val, ArrayList args)
        {
            int nbArgs = args.Count;
            switch (val.nameFunction.ToLower())
            {
                case "sendmsg":
                    val.sval = "\"\"";
                    val.typVal = typVal.str;
                    return;
            }
            throw new Exception("Function not defined..." + val.nameFunction);
        }
    }
}
