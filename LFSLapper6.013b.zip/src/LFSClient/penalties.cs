//  
//  penalties.cs
//  
//  Author:
//       Robert BRACCAGNI alias Gai-Luron <lfsgailuron@free.fr>
// 
//  Copyright (c) 2010 Gai-Luron
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.


using System;
namespace LFSLapper
{
    partial class LFSClient
    {
        void OnPenalties(infoPlayer currInfoPlayer, InSim.Decoder.PEN pen)
        {
            string action ="";
            switch (pen.Reason)
            {
                case ((int)InSim.penr.PENR_FALSE_START):
                    if (pen.NewPen == (int)(InSim.pen.PENALTY_30) || pen.NewPen == (int)(InSim.pen.PENALTY_DT))
                    {
                        action = "OnFalseStartL1";
                    }
                    if (pen.NewPen == (int)(InSim.pen.PENALTY_45) || pen.NewPen == (int)(InSim.pen.PENALTY_SG))
                    {
                        action = "OnFalseStartL2";
                    }
                    break;
                case ((int)InSim.penr.PENR_SPEEDING):
                    if (pen.NewPen == (int)(InSim.pen.PENALTY_30) || pen.NewPen == (int)(InSim.pen.PENALTY_DT))
                    {
                        action = "OnFastDriveOnPitL1";
                    }
                    if (pen.NewPen == (int)(InSim.pen.PENALTY_45) || pen.NewPen == (int)(InSim.pen.PENALTY_SG))
                    {
                        action = "OnFastDriveOnPitL2";
                    }
                    currInfoPlayer.NbFastDriveOnPit++;
                    if (currInfoPlayer.NbFastDriveOnPit >= newCfg.varsLapper.MaxFastDriveOnPit)
                        action = "OnMaxFastDriveOnPit";
                    break;
                default:
//                    Console.WriteLine("Penalty not catched " + Enum.GetName(typeof(InSim.penr), pen.Reason));
                    break;
            }
            try
            {
                string[] args = new string[1];
                args[0] = currInfoPlayer.userName;
                newCfg.executeFunction(action, currInfoPlayer, args);
            }
            catch (Exception e)
            {
                myDebug.WriteLine("err","Error " + e.ToString());
            }
        }
    }
}