//  
//  RegisterWeb.cs
//  
//  Author:
//       Robert BRACCAGNI alias Gai-Luron <lfsgailuron@free.fr>
// 
//  Copyright (c) 2010 Gai-Luron
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.


using System;
using System.Collections;
using System.Threading;
using System.IO;
using System.Net;
using LFSLapper;
using System.Net.Cache;
using Configurator;



namespace LapperThreads
{
    public class registerWeb
    {
        public string HName = "";
        public string Ver = "";
        private GLDebug.Debug myDebug;
        public registerWeb( GLDebug.Debug pmyDebug )
        {
            this.myDebug = pmyDebug;
        }
        public void RegisterLoop(){
            string readLine;
            string url;

            myDebug.WriteLine("mss","Register Web Thread Started...");
            while (true)
            {
                if( this.HName == "" ){
                    System.Threading.Thread.Sleep(5000);
                    continue;
                }
//                Console.WriteLine("Register on web " + this.HName);
                try
                {
                    url = "http://www.frh-team.net/reglapper/register.php"
                        + "?serv=" + this.HName
                        + "&ver=" + this.Ver
                    ;
                    WebRequest req = WebRequest.Create(url);
                    req.Timeout = (int)paramLapper.webTimeOut;
                    RequestCachePolicy policy = new RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);

                    WebResponse result = req.GetResponse();
                    Stream receiveStream = result.GetResponseStream();
                    using (StreamReader sr = new StreamReader(receiveStream))
                    {
                        while (true)
                        {
                            readLine = sr.ReadLine();
                            if (readLine == null)
                                break;
//                            Console.WriteLine(readLine);
                        }
                    }
                }
                catch
                {
                }
                System.Threading.Thread.Sleep((int)paramLapper.delayedRegisterWeb * 60 * 1000);
            }
        }
    }

}
