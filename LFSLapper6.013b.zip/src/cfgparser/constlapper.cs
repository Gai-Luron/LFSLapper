//  
//  constlapper.cs
//  
//  Author:
//       Robert BRACCAGNI alias Gai-Luron <lfsgailuron@free.fr>
// 
//  Copyright (c) 2010 Gai-Luron
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.


using System;
using System.Collections.Generic;
using System.Text;

namespace LFSLapper
{
    public class paramLapper
    {
        public const int maxSplit = 3;
        public const int delayedSave = 120;  // Delay beetxeen 2 save delayed in second
        public const int delayedRegisterWeb = 15;  // Delay beetween 2 registration on web in minute
        public const int webTimeOut = 10000;  // Timeout in ms on Web Request
        public const int nbLineTop = 18;        // Multiple of 2
        public const int debugmode = 0;      // Allow logerr.txt to be generated for error reporting
        public const int maxLogSize = 2 * 1024 * 1024;
        public const int secToNextWorkMode = 6;
    }
}
