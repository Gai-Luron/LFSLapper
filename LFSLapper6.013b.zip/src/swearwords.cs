//  
//  swearwords.cs
//  
//  Author:
//       Robert BRACCAGNI alias Gai-Luron <lfsgailuron@free.fr>
// 
//  Copyright (c) 2010 Gai-Luron
// 
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.


using System;
namespace LFSLapper
{

    class swearwords
    {
        System.Collections.Hashtable Hswearwords = new System.Collections.Hashtable();

        public bool load(string workingDir, string SwearWordsList)
        {
            string readLine;
            int lineCounter = 0;
            string filePath;

            if (SwearWordsList != "" && SwearWordsList[0] == '&')
                filePath = SwearWordsList.Substring(1);
            else
            {
                string[] splitStr = SwearWordsList.Split(',');
                for( int i = 0; i < splitStr.Length;i++ )
                    Hswearwords[splitStr[i].ToLower()] = true;
                return true;
            }

            if (filePath == "")
                return false;
            try{

                using (System.IO.StreamReader sr = new System.IO.StreamReader(workingDir + "/" + filePath))
                {
                    while (true)
                    {
                        lineCounter++;
                        readLine = sr.ReadLine();
                        if (readLine == null)
                            break;
                        if (readLine.Trim() != "")
                            Hswearwords[readLine.ToLower()] = true;

                    }
                }
                return true;
            }
            catch{
                return false;
            }
        }
        public bool findSwearWords( string str ){

            str = str.Replace('.', ' ')
                    .Replace(',',' ')
                    .Replace(';',' ')
                    .Replace('!',' ')
                    .Replace('?', ' ')
                    .Replace('/', ' ')
            ;
            string []splitStr = str.Split(' ');
            for( int i = 0; i < splitStr.Length;i++ ){
                if( Hswearwords.ContainsKey( splitStr[i].ToLower()))
                    return true;
            }
            return false;

        }
   }
}